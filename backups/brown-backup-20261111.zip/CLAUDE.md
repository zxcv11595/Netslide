# 밀어밀어 햄스터 (Slide Hamster)

줄을 밀어 굴을 잇고 모든 햄스터에게 간식을 보내는 퍼즐. 웹과 앱(구글 플레이) 출시 예정.
Vite + Vanilla JavaScript + HTML/CSS, 보드는 SVG. 로컬 커밋만 있고 원격/배포 없음.

## 작업 방식
- 채팅 지시가 기준이다. `docs/archive/`, `docs/ui-release-study/`는 예전 자료라 요청이 없으면 읽지 않는다.
- 화면을 바꿀 때는 먼저 시안을 review-gallery 검토 페이지(`output/`)로 보여 주고, 고른 뒤 게임에 반영한다.
- 남은 일은 `docs/TODO.md`에 있다. 필요할 때만 읽고, 끝낸 항목은 지운다.
- 토큰 절약:
  - `src/data/stages.json`, `tools/out/solutions.json`, `package-lock.json`, `dist/`는 통째로 읽지 않는다(읽기 차단됨). 판 하나가 필요하면 `node -e`로 그 부분만 뽑는다.
  - 동작 확인은 `npm test`, `npm run verify`로 한다. 스크린샷은 시안 검토나 화면 변경 확인 때만 찍는다.
  - `npm run generate`는 1~2분 걸리므로 판 데이터를 바꿀 때만 돌린다.

## 명령
- `npm run dev` / `npm test` / `npm run verify` / `npm run generate` / `npm run build`

## 게임 규칙 (확정)
- Netslide 방식: 모든 칸이 하나의 굴(나무 구조)에 속하고 가지 끝마다 햄스터가 있다. 쓸모없는 수로와 보너스 없음.
- 가장자리 버튼은 바깥쪽으로 민다. 왼쪽 ←/왼쪽 이동, 오른쪽 →/오른쪽 이동, 위 ↑/위 이동, 아래 ↓/아래 이동. 표시와 실제 이동이 같아야 한다. 끝 칸은 반대편으로 돌아온다. 회전 없음.
- 간식 창고(공급원)가 있는 행과 열은 잠김.
- 모든 햄스터에게 굴이 닿으면 자동으로 배달 완료(완료 버튼 없음).
- 별: 이동 수 기준. 3별 = 최단 수(미증명 판은 생성 때 알던 해답 길이), 2별 = 3별 + 3, 그 외 1별.
- 어렵게 만드는 것이 핵심. 햄스터는 판당 1~7마리.

## 난이도와 판
- 입문 2×2 (3판, 누를 화살표 항상 표시) / 초급 3×3 (12판) / 중급 4×4 (12판) / 고급 5×5 (12판) / 익스트림은 점선 자리만.
- 오늘의 도전 28판(4×4, 5×5 혼합), 한국 시간 날짜 기준 순환.
- 고급 8판과 중급 마지막 1판은 최단 수 미증명(탐색 한계).
- 콘텐츠 버전은 공개 전이라 1 유지.

## 화면 (2026-11-11 최신 정정 — 단일 운영 디자인)
- 운영 게임은 한 가지 디자인만 쓴다. 월넛 갈색 바탕/보드와 채도를 낮춘 나무 베이지 HUD/버튼/패널로 통일한다. 넓은 흰색 면, 레몬색, 검정 테두리를 피하고 같은 갈색 계열 안에서 명도를 나눈다. 주황/황갈색은 연결 상태와 주요 행동에 집중한다.
- 흰색 원본은 backups/white-original-20261111.zip의 별도 백업이다. 게임 내 테마 선택/설정/저장은 없다. 앞선 ‘두 테마 전환’ 해석은 잘못됐으므로 다시 넣지 않는다.
- src/themes/brown.css는 현재 단일 디자인의 색상/표면 스타일이다. 이름이 themes여도 선택 가능한 테마 시스템이 아니다. data-game-theme와 settings.gameTheme는 운영 코드에서 제거했다. 구버전 저장에 해당 필드가 있으면 무시하고 실제 기록·힌트·진동은 보존한다.
- 배치와 둥근 길 모양, 은은한 잔결은 유지한다. 거친 판재 이음새/각진 발판을 다시 적용하지 않는다.
- 바깥쪽 화살표 조작은 유지한다. 검토 기록: output/wood-path-review-20261111-fix5/.

### 백업 원본의 기준색
- 색: 배경 #fff9ee, 패널 #fff1d8, 타일 #f4e0bd, 글씨 #55301d, 포인트 #ee962b, 테두리 #e1c59e
- 준비 중인 기능은 점선으로 표시한다(광고 제거, 광고 자리, 상점 상품, 설정의 소리·언어·구매 복원·개인정보 처리방침·문의하기, 익스트림).
- 굴은 테두리 + 씨앗 점선, 타일 햄스터는 원본 그림 얼굴(대기/성공).

## 힌트
- 다음에 밀 줄 하나만 표시, 1개 차감. 처음 3개, 그날의 오늘의 도전을 처음 끝내면 +1.
- 지금 배치에서 탐색: 최단 BFS → 보관 해답 경로 → 가중 A* → 실패하면 되돌리기 안내.

## 주요 파일
- `src/core/rules.js` 규칙, `src/core/solver.js` BFS·findPath
- `src/game/` session, progress, daily, links, hint
- `src/ui/` home, screens(스테이지·도전·상점·기록·설정), play, board, common, art
- `src/storage/storage.js` localStorage, `src/ads/adManager.js` 기본 비활성
- `src/config.js` 이름·버전·설정, `index.html` 로딩 화면
- `src/data/stages.json` 판, `src/data/hints.json` 힌트용 해답, `tools/out/solutions.json` 검증 자료, `docs/STAGE_REPORT.md` 보고서
- `tools/generate.js`, `tools/verify.js`, `tests/*.test.js`

## 정해진 방향
- 이름: 한국어 "밀어밀어 햄스터", 영어 "Slide Hamster". 제목에 Netslide는 넣지 않고 설명에 영감 출처로만 적는다.
- 수익: 웹은 광고 없이 출시 → 반응 보고 판 사이 광고 → 앱에서 광고 제거 결제와 힌트.
