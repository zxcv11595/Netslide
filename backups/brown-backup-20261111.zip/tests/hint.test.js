// 이어서 안내하는 힌트, 바로 클리어 기록, 힌트 지급
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createStore, sanitize } from '../src/storage/storage.js';
import { confirmCompletion } from '../src/game/progress.js';
import { parseContent } from '../src/data/parse.js';
import { createSession } from '../src/game/session.js';
import { moveFromCode } from '../src/core/rules.js';
import { planHint, guideCount, simplifyHistory } from '../src/game/hint.js';
import { grantDailyHint, grantStarHints, regularStars } from '../src/game/hintWallet.js';

const raw = JSON.parse(readFileSync(new URL('../src/data/stages.json', import.meta.url), 'utf8'));
const hints = JSON.parse(readFileSync(new URL('../src/data/hints.json', import.meta.url), 'utf8')).hints;
const content = parseContent(raw);
const CFG = { dailyFree: 1, freeCap: 3, starsPer: 10 };

function memStore() {
  const map = new Map();
  return createStore({ key: 'k', backend: { getItem: (k) => (map.has(k) ? map.get(k) : null), setItem: (k, v) => map.set(k, String(v)), removeItem: (k) => map.delete(k) } });
}
const done = (stars) => ({ canComplete: true, requiredDone: true, hasBonus: false, bonusDone: false, stars });
function scramble(stage, count, seedStart) {
  let seed = seedStart;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  const session = createSession(stage);
  const lines = [];
  for (let i = 0; i < stage.size; i++) for (const axis of ['row', 'col']) for (const dir of [1, -1]) lines.push({ axis, index: i, dir });
  let made = 0;
  while (made < count) { if (session.move(lines[Math.floor(rnd() * lines.length)]).ok) made++; }
  return session;
}
function play(session, codes) {
  for (const c of codes) assert.equal(session.move(moveFromCode(c)).ok, true, c);
}

test('이력 단축: 서로 지워지는 수를 없애도 도착 배치는 같다', () => {
  const stage = content.byId.get('M05');
  assert.deepEqual(simplifyHistory(stage, ['r0+', 'r0-']), []);
  assert.deepEqual(simplifyHistory(stage, ['c1+', 'r0+', 'r0-', 'c1-']), []);
  assert.deepEqual(simplifyHistory(stage, ['r0+', 'r0+', 'r0+', 'r0+']), [], '4칸 판에서 한 바퀴');
  assert.deepEqual(simplifyHistory(stage, ['r0+', 'r0+', 'r0+']), ['r0-'], '가까운 방향으로');
  for (const id of ['B12', 'M10', 'A04']) {
    const st = content.byId.get(id);
    const a = scramble(st, 14, 77);
    const b = createSession(st);
    play(b, simplifyHistory(st, a.historyCodes()));
    assert.deepEqual(b.cells, a.cells, id);
    assert.ok(b.moves <= a.moves);
  }
});

test('힌트 길: 처음 배치에서는 최단 길을 찾고, 절반(올림, 최소 2수)을 안내한다', () => {
  for (const id of ['B07', 'M02', 'M08', 'A01']) {
    const stage = content.byId.get(id);
    const session = createSession(stage);
    const plan = planHint(stage, session.cells, [], hints[id], { maxStates: 300000 });
    assert.equal(plan.type, 'path', id);
    assert.equal(plan.kind, 'near', id);
    assert.equal(plan.moves.length, stage.star3, `${id}: 최단 수`);
    assert.equal(guideCount(plan), Math.max(2, Math.ceil(stage.star3 / 2)), id);
  }
  assert.equal(guideCount({ moves: ['r0+'], back: 0 }), 1, '남은 수보다 많이 안내하지 않는다');
  assert.equal(guideCount({ moves: Array(12).fill('r0+'), back: 0 }), 6);
  assert.equal(guideCount({ moves: Array(10).fill('r0+'), back: 4 }), 7, '돌아가는 구간 전부 + 나머지의 절반');
});

test('힌트 길: 흐트러진 배치에서도 찾은 길을 그대로 따라가면 풀린다', () => {
  for (const id of ['B12', 'M05', 'M10', 'A04', 'A12']) {
    const stage = content.byId.get(id);
    const session = scramble(stage, 9, 4242);
    const plan = planHint(stage, session.cells, session.historyCodes(), hints[id], { maxStates: 20000 });
    assert.equal(plan.type, 'path', id);
    play(session, plan.moves);
    assert.equal(session.result.canComplete, true, `${id} (${plan.kind}, ${plan.moves.length}수)`);
  }
});

test('힌트 길: 탐색이 실패하면 돌아가는 길을 주고, 해답과 겹치는 앞부분은 돌아가지 않는다', () => {
  const stage = content.byId.get('A12');
  const solution = hints.A12;
  const tiny = { maxStates: 30 };
  // 해답 경로 위에 있으면 나머지 해답을 그대로 준다
  const on = createSession(stage);
  play(on, solution.slice(0, 2));
  const p1 = planHint(stage, on.cells, on.historyCodes(), solution, tiny);
  assert.deepEqual([p1.kind, p1.back, p1.moves], ['near', 0, solution.slice(2)]);
  // 해답 2수 뒤에 다른 줄을 두 번 밀었으면 그 두 수만 돌아간다
  const off = createSession(stage);
  play(off, solution.slice(0, 2));
  const third = moveFromCode(solution[2]);
  const stray = { axis: third.axis === 'row' ? 'col' : 'row', index: 0, dir: 1 };
  const strayOk = off.move(stray).ok ? stray : { ...stray, index: 1 };
  if (strayOk !== stray) assert.equal(off.move(strayOk).ok, true);
  assert.equal(off.move(strayOk).ok, true);
  const p2 = planHint(stage, off.cells, off.historyCodes(), solution, tiny);
  assert.equal(p2.type, 'path');
  if (p2.kind === 'detour') assert.equal(p2.back, 2);
  play(off, p2.moves);
  assert.equal(off.result.canComplete, true);
  // 해답 자료가 없고 탐색도 실패하면 알려 줄 것이 없다
  assert.deepEqual(planHint(stage, createSession(stage).cells, [], null, tiny), { type: 'none' });
});

test('힌트 길: 시간 제한을 주면 그 안에 끝난다', () => {
  const stage = content.byId.get('A12');
  const session = scramble(stage, 25, 99);
  const t0 = performance.now();
  const plan = planHint(stage, session.cells, session.historyCodes(), hints.A12, { maxStates: 5000000, budgetMs: 200 });
  const took = performance.now() - t0;
  assert.ok(took < 1500, `걸린 시간 ${took.toFixed(0)}ms`);
  assert.equal(plan.type, 'path');
  play(session, plan.moves);
  assert.equal(session.result.canComplete, true);
});

test('바로 클리어: 별 1개로 기록하고 최소 이동 기록은 건드리지 않는다', () => {
  const stage = content.byId.get('B01');
  const s = memStore();
  const first = confirmCompletion(s, content, stage, done(3), 2, null, { skipped: true });
  assert.deepEqual([first.record.stars, first.record.best, first.firstClear], [1, null, true]);
  const real = confirmCompletion(s, content, stage, done(2), 5);
  assert.deepEqual([real.record.stars, real.record.best], [2, 5]);
  const again = confirmCompletion(s, content, stage, done(3), 2, null, { skipped: true });
  assert.deepEqual([again.record.stars, again.record.best, again.newBest], [2, 5, false], '직접 푼 기록이 내려가지 않는다');
  // 오늘의 도전도 같은 방식
  const daily = content.daily[0];
  const d = confirmCompletion(s, content, daily, done(3), 6, { date: '2026-11-11' }, { skipped: true });
  assert.equal(d.record.stars, 1);
  assert.deepEqual(s.content(content.version).daily['2026-11-11'], { id: daily.id, stars: 1, moves: null, bonus: false });
});

test('힌트 지급: 날마다 1개(처음 날 제외, 3개 미만일 때만)', () => {
  const s = memStore();
  assert.equal(grantDailyHint(s, '2026-11-11', CFG), 0, '처음 시작한 날은 시작 힌트만');
  assert.equal(s.data.hints, 3);
  s.data.hints = 0;
  assert.equal(grantDailyHint(s, '2026-11-11', CFG), 0, '같은 날은 다시 주지 않는다');
  assert.equal(grantDailyHint(s, '2026-11-12', CFG), 1);
  assert.equal(grantDailyHint(s, '2026-11-12', CFG), 0);
  s.data.hints = 3;
  assert.equal(grantDailyHint(s, '2026-11-13', CFG), 0, '3개 이상이면 주지 않는다');
  assert.equal(s.data.hints, 3);
  const kept = sanitize(JSON.parse(JSON.stringify(s.data)));
  assert.deepEqual([kept.hintDay, kept.starHints], ['2026-11-13', 0]);
  assert.equal(sanitize({ v: 1, hintDay: 'x', starHints: -1 }).hintDay, null);
});

test('힌트 지급: 정규 판 별 10개마다 1개, 두 번 주지 않는다', () => {
  const s = memStore();
  const list = content.groups.beginner;
  for (let i = 0; i < 3; i++) confirmCompletion(s, content, list[i], done(3), 3);
  assert.equal(regularStars(s, content), 9);
  assert.equal(grantStarHints(s, content, CFG), 0);
  confirmCompletion(s, content, list[3], done(1), 9);
  assert.equal(grantStarHints(s, content, CFG), 1);
  assert.equal(s.data.hints, 4);
  assert.equal(grantStarHints(s, content, CFG), 0);
  // 오늘의 도전 별은 세지 않는다
  confirmCompletion(s, content, content.daily[0], done(3), 6, { date: '2026-11-11' });
  assert.equal(regularStars(s, content), 10);
  for (let i = 4; i < 8; i++) confirmCompletion(s, content, list[i], done(3), 3);
  assert.equal(grantStarHints(s, content, CFG), 1, '22개가 되면 한 개 더');
  assert.equal(s.data.starHints, 2);
});
