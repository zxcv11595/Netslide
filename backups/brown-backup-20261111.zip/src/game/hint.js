// 힌트: 플레이어의 "지금 배치"에서 다음에 밀 줄을 알려 준다.
// nextHint는 한 수만(입문 안내용), planHint는 끝까지 가는 길(힌트 버튼용)을 돌려준다.
//
// nextHint의 순서
// 1) 지금 배치에서 최단 풀이를 직접 찾는다(BFS). 풀이까지 몇 수 안 남았으면 여기서 끝난다.
// 2) 지금까지의 이동이 보관된 해답의 앞부분과 같으면 해답의 다음 수를 알려 준다.
// 3) 지금 배치에서 "풀리는 길 하나"를 찾는다(가중 A*). 최단은 아닐 수 있다.
// 4) 그래도 못 찾으면 되돌리기를 권한다. 되돌리다 보면 1~3이 다시 통한다.
//    (많이 흐트러진 5×5는 실시간으로 풀 수 없는 경우가 있어서 이 단계가 필요하다)
import {
  moveFromCode, moveToCode, inverseMove, shiftBoard, initialCells, tileCode,
} from '../core/rules.js';
import { solve, findPath } from '../core/solver.js';

// 반환: { type: 'move', move } | { type: 'undo' } | { type: 'none' }
export function nextHint(stage, cells, historyCodes, solutionCodes = null, { maxStates = 40000 } = {}) {
  // 지금 배치를 시작 배치로 하는 임시 판
  const here = { ...stage, tiles: cells.map((id) => stage.tiles[id]) };
  const found = solve(here, { maxStates });
  if (found.basic) {
    if (found.basic.length === 0) return { type: 'none' };
    return { type: 'move', move: moveFromCode(found.basic.moves[0]) };
  }
  const hasSolution = Array.isArray(solutionCodes) && solutionCodes.length > 0;
  if (hasSolution && historyCodes.length < solutionCodes.length
    && historyCodes.every((c, i) => c === solutionCodes[i])) {
    return { type: 'move', move: moveFromCode(solutionCodes[historyCodes.length]) };
  }
  // 풀린 배치(타일 종류 배열)를 알면 그것을 목표로 삼아 더 잘 찾는다
  const target = hasSolution ? solvedTarget(stage, solutionCodes) : null;
  const path = findPath(here, { maxStates, weight: 3, target });
  if (path && path.moves.length > 0) return { type: 'move', move: moveFromCode(path.moves[0]) };
  return historyCodes.length > 0 ? { type: 'undo' } : { type: 'none' };
}

// 보관 해답을 끝까지 재생한 배치의 타일 종류 배열. 재생이 안 되면 null.
function solvedTarget(stage, solutionCodes) {
  let solved = initialCells(stage);
  for (const code of solutionCodes) {
    const res = shiftBoard(stage, solved, moveFromCode(code));
    if (!res.ok) return null;
    solved = res.cells;
  }
  return solved.map((id) => tileCode(stage.tiles[id]));
}

// ---------- 이어서 안내하는 힌트 ----------
const now = () => (globalThis.performance?.now ? globalThis.performance.now() : Date.now());
const invCode = (code) => moveToCode(inverseMove(moveFromCode(code)));

// 이력에서 서로 지워지는 수를 없앤다(같은 줄을 반대로 민 것, 한 바퀴 돌린 것). 도착 배치는 같다.
export function simplifyHistory(stage, codes) {
  const n = stage.size;
  const stack = []; // { axis, index, net }
  for (const code of codes) {
    const m = moveFromCode(code);
    if (!m) continue;
    const top = stack[stack.length - 1];
    if (top && top.axis === m.axis && top.index === m.index) {
      top.net = (((top.net + m.dir) % n) + n) % n;
      if (top.net === 0) stack.pop();
    } else {
      stack.push({ axis: m.axis, index: m.index, net: ((m.dir % n) + n) % n });
    }
  }
  const out = [];
  for (const s of stack) {
    const steps = s.net > n / 2 ? s.net - n : s.net; // 가까운 방향으로
    for (let i = 0; i < Math.abs(steps); i++) out.push(moveToCode({ axis: s.axis, index: s.index, dir: steps > 0 ? 1 : -1 }));
  }
  return out;
}

// 지금 배치에서 끝까지 가는 길 하나를 찾는다.
// 반환: { type: 'none' } | { type: 'path', kind, moves, back, exact }
//   kind 'near'   : 지금 배치에서 앞으로 찾은 길
//   kind 'detour' : 가까운 길을 못 찾아, 민 것을 back수만큼 거슬러 간 뒤 보관 해답을 따르는 길
//   exact         : moves 길이가 최단임이 확인됨
// budgetMs를 주면 그 시간 안에서만 찾는다(탐색 60% → 가중 탐색 40%).
export function planHint(stage, cells, historyCodes, solutionCodes = null, { maxStates = 40000, budgetMs = 0 } = {}) {
  const t0 = now();
  const here = { ...stage, tiles: cells.map((id) => stage.tiles[id]) };
  const found = solve(here, { maxStates, deadline: budgetMs ? t0 + budgetMs * 0.6 : 0 });
  if (found.basic) {
    if (found.basic.length === 0) return { type: 'none' };
    return { type: 'path', kind: 'near', moves: found.basic.moves, back: 0, exact: true };
  }
  const hasSolution = Array.isArray(solutionCodes) && solutionCodes.length > 0;
  const target = hasSolution ? solvedTarget(stage, solutionCodes) : null;

  // 거슬러 가는 길: 단축한 이력이 해답과 갈라진 곳까지만 돌아가서 해답을 잇는다. 계산이 필요 없다.
  let detour = null;
  if (target) {
    const simple = simplifyHistory(stage, historyCodes);
    let k = 0;
    while (k < simple.length && k < solutionCodes.length && simple[k] === solutionCodes[k]) k++;
    const backMoves = simple.slice(k).reverse().map(invCode);
    detour = { moves: [...backMoves, ...solutionCodes.slice(k)], back: backMoves.length };
    // 해답 경로 위에 그대로 있으면 더 찾지 않는다
    if (detour.back === 0 && detour.moves.length > 0) {
      return { type: 'path', kind: 'near', moves: detour.moves, back: 0, exact: false };
    }
  }
  const path = findPath(here, { maxStates, weight: 3, target, deadline: budgetMs ? t0 + budgetMs : 0 });
  const forward = path && path.moves.length > 0 ? path.moves : null;
  if (forward && (!detour || forward.length <= detour.moves.length)) {
    return { type: 'path', kind: 'near', moves: forward, back: 0, exact: false };
  }
  if (detour && detour.moves.length > 0) {
    return { type: 'path', kind: 'detour', moves: detour.moves, back: detour.back, exact: false };
  }
  return { type: 'none' };
}

// 힌트 하나로 안내할 수: 거슬러 가는 구간 전부 + 남은 길의 절반(올림, 최소 minGuide수)
export function guideCount(plan, minGuide = 2) {
  const rest = plan.moves.length - plan.back;
  return Math.min(plan.moves.length, plan.back + Math.max(minGuide, Math.ceil(rest / 2)));
}
