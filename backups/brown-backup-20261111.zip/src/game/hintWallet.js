// 힌트를 얻는 길(결제·광고 제외): 날마다 접속, 별 모으기. 오늘의 도전 보상은 완료 처리에서 준다.
import { CONFIG } from '../config.js';

const REGULAR = ['beginner', 'intermediate', 'advanced'];

// 날마다 처음 들어올 때 1개. 보유 수가 freeCap 이상이면 주지 않는다(쌓아 두기 방지).
// 반환: 받은 개수
export function grantDailyHint(store, today, cfg = CONFIG.hints) {
  if (store.data.hintDay === today) return 0;
  const first = store.data.hintDay == null; // 처음 시작한 날은 시작 힌트로 충분하다
  store.data.hintDay = today;
  let got = 0;
  if (!first && store.data.hints < cfg.freeCap) {
    got = Math.min(cfg.dailyFree, cfg.freeCap - store.data.hints);
    store.data.hints += got;
  }
  store.save();
  return got;
}

export function regularStars(store, content) {
  const recs = store.content(content.version).records;
  let sum = 0;
  for (const g of REGULAR) for (const s of content.groups[g]) sum += recs[s.id]?.stars ?? 0;
  return sum;
}

// 정규 판 별이 starsPer개 늘 때마다 1개. 이미 준 횟수를 기억해서 두 번 주지 않는다.
// 반환: 받은 개수
export function grantStarHints(store, content, cfg = CONFIG.hints) {
  const due = Math.floor(regularStars(store, content) / cfg.starsPer);
  const got = Math.max(0, due - (store.data.starHints || 0));
  if (got > 0) {
    store.data.starHints = due;
    store.data.hints += got;
    store.save();
  }
  return got;
}
