// 게임 전역 설정. 이름·이미지 경로·광고 실험값은 여기 한곳에서 바꾼다.
export const CONFIG = {
  gameName: '밀어밀어 햄스터', // 영어 이름: Slide Hamster
  logoLines: ['밀어밀어', '햄스터'], // 홈과 로딩 화면에서 줄을 나눠 크게 보여 주는 이름
  version: '1.0.0',
  storageKey: 'hamster-snack-delivery',

  // public/ 아래 경로(배포 하위 경로에서도 동작하도록 상대 경로)
  assets: {
    hamsterIdle: 'assets/hamster-idle.png',
    hamsterSuccess: 'assets/hamster-success.png',
    snackSeed: 'assets/snack-seed.png',
  },

  // 애니메이션 시작값(ms)
  anim: {
    shift: 170,
    shiftFallback: 320, // 전환 종료 이벤트가 오지 않아도 잠금을 푸는 시간
    flowStep: 40,
    flowMax: 320,
    completeDelay: 520, // 모두 이어진 뒤 결과가 뜨기까지
    successSwap: 120,
    starStep: 100,
  },

  // 힌트. 처음 주는 개수는 storage.js의 START_HINTS(3)다.
  hints: {
    clearCost: 3, // 바로 클리어에 쓰는 힌트 수(별 1개로 기록)
    minGuide: 2, // 힌트 하나로 안내하는 최소 수. 실제로는 남은 길의 절반(올림)
    searchMs: 1000, // 길 찾기 제한 시간
    waitNoticeMs: 300, // 이 시간을 넘기면 "길을 찾는 중" 표시
    maxStates: 300000, // 길 찾기에서 살펴볼 배치 수 상한(보통 시간 제한이 먼저 걸린다)
    dailyFree: 1, // 날마다 처음 접속할 때 주는 힌트
    freeCap: 3, // 날마다 주는 힌트는 보유 수가 이보다 적을 때만
    starsPer: 10, // 정규 판 별을 이만큼 모을 때마다 힌트 1개
    dailyClear: 1, // 그날의 오늘의 도전을 처음 끝내면
    autoStepMs: 260, // 바로 클리어에서 한 수를 보여 주는 간격
  },

  // 광고: 사업자 미정이므로 기본 비활성. provider가 없으면 항상 즉시 통과한다.
  ads: {
    enabled: false,
    minDistinctStages: 3, // 이전 실제 노출 이후 완료한 서로 다른 정규 판 수
    minPlayMs: 5 * 60 * 1000, // 이전 실제 노출(또는 입문 종료) 이후 일반 플레이 시간
    requestTimeoutMs: 3000, // 표시가 시작되기 전까지만 적용. 표시 중에는 타임아웃으로 재개하지 않는다.
    retryCooldownMs: 60 * 1000, // 재고 없음/실패 뒤 재요청 대기
  },
};

export const GROUP_LABEL = {
  tutorial: '입문',
  beginner: '초급',
  intermediate: '중급',
  advanced: '고급',
  daily: '오늘의 도전',
};

export const TUTORIAL_TEXT = {
  T1: '화살표를 누르면 줄이 밀려요. 밀려난 칸은 반대편으로 돌아와요.',
  T2: '가로줄도 밀 수 있어요. 자물쇠 줄은 간식 창고가 있어 움직이지 않아요.',
  T3: '햄스터 모두에게 굴이 닿으면 배달 끝!',
};
